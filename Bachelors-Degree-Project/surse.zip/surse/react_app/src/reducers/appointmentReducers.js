import {
        REQUEST_APPOINTMENT_REQUEST,
        REQUEST_APPOINTMENT_SUCCESS,
        REQUEST_APPOINTMENT_FAIL,
        REQUEST_APPOINTMENT_RESET,

        ACCEPT_APPOINTMENT_REQUEST,
        ACCEPT_APPOINTMENT_SUCCESS,
        ACCEPT_APPOINTMENT_FAIL,
        ACCEPT_APPOINTMENT_RESET,

        APPOINTMENT_LIST_REQUEST,
        APPOINTMENT_LIST_SUCCESS,
        APPOINTMENT_LIST_FAIL,

        REJECT_APPOINTMENT_REQUEST,
        REJECT_APPOINTMENT_SUCCESS,
        REJECT_APPOINTMENT_FAIL,

        EDIT_APPOINTMENT_REQUEST,
        EDIT_APPOINTMENT_SUCCESS,
        EDIT_APPOINTMENT_FAIL,
        EDIT_APPOINTMENT_RESET,

        DELETE_APPOINTMENT_REQUEST,
        DELETE_APPOINTMENT_SUCCESS,
        DELETE_APPOINTMENT_FAIL,
} from '../constants/appointmentConstants'

export const appointmentListReducer =  (state = { appointments: [] }, action) =>{
    switch(action.type){
        case APPOINTMENT_LIST_REQUEST:
            return {loading: true, appointments: []}

        case APPOINTMENT_LIST_SUCCESS:
            const appointments = Array.isArray(action.payload.appointments)
                ? action.payload.appointments
                : []

            return { loading: false, appointments }
            // return {loading: false, appointments: action.payload}
        
        case APPOINTMENT_LIST_FAIL:
            return {loading: false, error: action.payload}

        default:
            return state
    }
}

export const requestAppointmentReducer = (state = {}, action) => {
    switch (action.type) {
        case REQUEST_APPOINTMENT_REQUEST:
            return { loading: true }

        case REQUEST_APPOINTMENT_SUCCESS:
            return { loading: false, success: true, }

        case REQUEST_APPOINTMENT_FAIL:
            return { loading: false, error: action.payload }

        case REQUEST_APPOINTMENT_RESET:
            return {}

        default:
            return state
    }
}

export const acceptAppointmentReducer = (state = {}, action) => {
    switch (action.type) {
        case ACCEPT_APPOINTMENT_REQUEST:
            return { loading: true }

        case ACCEPT_APPOINTMENT_SUCCESS:
            return { loading: false, success: true, }

        case ACCEPT_APPOINTMENT_FAIL:
            return { loading: false, error: action.payload }

        case ACCEPT_APPOINTMENT_RESET:
            return {}

        default:
            return state
    }
}

export const rejectAppointmentReducer = (state = {}, action) => {
    switch (action.type) {

      case REJECT_APPOINTMENT_REQUEST:
        return { loading: true }

      case REJECT_APPOINTMENT_SUCCESS:
        return { loading: false, success: true }

      case REJECT_APPOINTMENT_FAIL:
        return { loading: false, error: action.payload }

      default:
        return state
    }
}

export const editAppointmentReducer = (state = {}, action) => {
    switch (action.type) {
        case EDIT_APPOINTMENT_REQUEST:
            return { loading: true }

        case EDIT_APPOINTMENT_SUCCESS:
            return { loading: false, success: true, appointment: action.payload}

        case EDIT_APPOINTMENT_FAIL:
            return { loading: false, error: action.payload }

        case EDIT_APPOINTMENT_RESET:
            return {}

        default:
            return state
    }
}

export const deleteAppointmentReducer = (state = {}, action) => {
    switch (action.type) {

      case DELETE_APPOINTMENT_REQUEST:
        return { loading: true }

      case DELETE_APPOINTMENT_SUCCESS:
        return { loading: false, success: true }

      case DELETE_APPOINTMENT_FAIL:
        return { loading: false, error: action.payload }

      default:
        return state
    }
}