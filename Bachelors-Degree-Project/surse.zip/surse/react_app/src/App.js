import { Container } from 'react-bootstrap'
import { BrowserRouter as Router, Route, Routes} from 'react-router-dom'
import Header from './components/Header'
import Footer from './components/Footer'
import HomeScreen from './screens/HomeScreen'
import HelpScreen from './screens/HelpScreen'
import MesterScreen from './screens/MesterScreen'
import LoginScreen from './screens/LoginScreen'
import RegisterScreen from './screens/RegisterScreen'
import ProfileScreen from './screens/ProfileScreen'
import AppointmentScreen from './screens/AppointmentScreen'

function App() {
  return (
    <Router>
      <Header />
      <main className='py-3'>
      <Container>
      <Routes>
        <Route path='/' element={<HomeScreen />} />
        <Route path='/help' element={<HelpScreen />} />
        <Route path='/login' element={<LoginScreen />} />
        <Route path='/register' element={<RegisterScreen />} />
        <Route path='/profile' element={<ProfileScreen />} />
        <Route path='/mester/:id' element={<MesterScreen/>} />
        <Route path='/appointments' element={<AppointmentScreen/>} />
        </Routes>
      </Container>
      </main>
      <Footer />
    </Router>
  );
}

export default App;
