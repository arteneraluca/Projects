import axios from 'axios'
import { MESTER_LIST_REQUEST,
         MESTER_LIST_SUCCESS, 
         MESTER_LIST_FAIL,

         MESTER_DETAILS_REQUEST,
         MESTER_DETAILS_SUCCESS, 
         MESTER_DETAILS_FAIL,

         MESTER_CREATE_REVIEW_REQUEST,
         MESTER_CREATE_REVIEW_SUCCESS,
         MESTER_CREATE_REVIEW_FAIL,

         MESTER_TOP_REQUEST,
         MESTER_TOP_SUCCESS,
         MESTER_TOP_FAIL,
} from '../constants/mesterConstants'

export const listMesteri = (keyword='') => async (dispatch) => {
    try{
        dispatch({type: MESTER_LIST_REQUEST})

        const {data} = await axios.get(`/api/mesteri${keyword}`)

        dispatch ({
            type: MESTER_LIST_SUCCESS,
            payload: data
        })

    } catch(error) {
        dispatch({
            type: MESTER_LIST_FAIL,
            payload: error.response && error.response.data.detail
            ? error.response.data.detail
            : error.message,
        })
    }
}

export const listMesterDetails = (id) => async (dispatch) => {
    try{
        dispatch({type: MESTER_DETAILS_REQUEST})

        const {data} = await axios.get(`/api/mesteri/${id}`)

        dispatch ({
            type: MESTER_DETAILS_SUCCESS,
            payload: data
        })

    } catch(error) {
        dispatch({
            type: MESTER_DETAILS_FAIL,
            payload: error.response && error.response.data.detail
            ? error.response.data.detail
            : error.message,
        })
    }
}

export const createMesterReview = (mesterId, review) => async (dispatch, getState) => {
    try {
        dispatch({
            type: MESTER_CREATE_REVIEW_REQUEST
        })

        const {
            userLogin: { userInfo },
        } = getState()

        const config = {
            headers: {
                'Content-type': 'application/json',
                Authorization: `Bearer ${userInfo.token}`
            }
        }

        const { data } = await axios.post(
            `/api/mesteri/${mesterId}/reviews/`,
            review,
            config
        )
        dispatch({
            type: MESTER_CREATE_REVIEW_SUCCESS,
            payload: data,
        })

    } catch (error) {
        dispatch({
            type: MESTER_CREATE_REVIEW_FAIL,
            payload: error.response && error.response.data.detail
                ? error.response.data.detail
                : error.message,
        })
    }
}

export const listTopMesteri = () => async (dispatch) => {
    try {
        dispatch({ type: MESTER_TOP_REQUEST })

        const { data } = await axios.get(`/api/mesteri/top/`)

        dispatch({
            type: MESTER_TOP_SUCCESS,
            payload: data
        })

    } catch (error) {
        dispatch({
            type: MESTER_TOP_FAIL,
            payload: error.response && error.response.data.detail
                ? error.response.data.detail
                : error.message,
        })
    }
}