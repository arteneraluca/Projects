import axios from 'axios'
import {
        REQUEST_APPOINTMENT_REQUEST,
        REQUEST_APPOINTMENT_SUCCESS,
        REQUEST_APPOINTMENT_FAIL,

        ACCEPT_APPOINTMENT_REQUEST,
        ACCEPT_APPOINTMENT_SUCCESS,
        ACCEPT_APPOINTMENT_FAIL,

        APPOINTMENT_LIST_REQUEST,
        APPOINTMENT_LIST_SUCCESS,
        APPOINTMENT_LIST_FAIL,

        REJECT_APPOINTMENT_REQUEST,
        REJECT_APPOINTMENT_SUCCESS,
        REJECT_APPOINTMENT_FAIL,

        EDIT_APPOINTMENT_REQUEST,
        EDIT_APPOINTMENT_SUCCESS,
        EDIT_APPOINTMENT_FAIL,
        EDIT_APPOINTMENT_RESET,

        DELETE_APPOINTMENT_REQUEST,
        DELETE_APPOINTMENT_SUCCESS,
        DELETE_APPOINTMENT_FAIL,
} from '../constants/appointmentConstants'

export const listMyAppointments = () => async (dispatch, getState) => {
    try {
        dispatch({
            type: APPOINTMENT_LIST_REQUEST
        })

        const {
            userLogin: { userInfo },
        } = getState()

        const config = {
            headers: {
                'Content-type': 'application/json',
                Authorization: `Bearer ${userInfo.token}`
            }
        }

        const { data } = await axios.get(
            `/api/appointments/list_apps/`,
            config
        )

        dispatch({
            type: APPOINTMENT_LIST_SUCCESS,
            payload: data
        })


    } catch (error) {
        dispatch({
            type: APPOINTMENT_LIST_FAIL,
            payload: error.response && error.response.data.detail
                ? error.response.data.detail
                : error.message,
        })
    }
}

export const createAppointment = (mesterId, appointmentData) => async (dispatch, getState) => {
    try {
        dispatch({ 
            type: REQUEST_APPOINTMENT_REQUEST
        })

        const {
            userLogin: { userInfo },
        } = getState()

        const config = {
            headers: {
            'Content-type': 'application/json',
            Authorization: `Bearer ${userInfo.token}`
            }
        }

        const { data } = await axios.post(
            `/api/appointments/${mesterId}/request_app/`,
            appointmentData,
            config
        )

        dispatch({ 
            type: REQUEST_APPOINTMENT_SUCCESS, 
            payload: data 
        })

    } catch (error) {
        dispatch({ 
            type: REQUEST_APPOINTMENT_FAIL, 
            payload: error.response && error.response.data.detail
                ? error.response.data.detail
                : error.message,
        })
    }
}

export const acceptAppointments = (appointmentId, startTime) => async (dispatch, getState) => {
    try {
        dispatch({ type: ACCEPT_APPOINTMENT_REQUEST })

        const {
        userLogin: { userInfo },
        } = getState()

        const config = {
        headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${userInfo.token}`,
        }}

        const { data } = await axios.put(
        `/api/appointments/${appointmentId}/accept_app/`,
        { start_time: startTime },
        config
        )

        dispatch({
        type: ACCEPT_APPOINTMENT_SUCCESS,
        payload: data,
        })

    } catch (error) {
        dispatch({
        type: ACCEPT_APPOINTMENT_FAIL,
        payload:
            error.response && error.response.data.message
            ? error.response.data.message
            : error.message,
        })
    }
}

export const rejectAppointments = (appointmentId, user) => async (dispatch, getState) => {
    try {
        dispatch({ type: REJECT_APPOINTMENT_REQUEST })

        const {
        userLogin: { userInfo },
        } = getState()

        const config = {
        headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${userInfo.token}`,
        }}

        const { data } = await axios.put(
        `/api/appointments/${appointmentId}/reject_app/`,
        user,
        config
        )

        dispatch({
        type: REJECT_APPOINTMENT_SUCCESS
        })

    } catch (error) {
        dispatch({
        type: REJECT_APPOINTMENT_FAIL,
        payload:
            error.response && error.response.data.message
            ? error.response.data.message
            : error.message,
        })
    }
}

export const editAppointments = (appointmentId, appointmentData) => async (dispatch, getState) => {
    try {
        dispatch({ 
            type: EDIT_APPOINTMENT_REQUEST
        })

        const {
            userLogin: { userInfo },
        } = getState()

        const config = {
            headers: {
            'Content-type': 'application/json',
            Authorization: `Bearer ${userInfo.token}`
            }
        }

        const { data } = await axios.put(
            `/api/appointments/${appointmentId}/edit_app/`,
            appointmentData,
            config
        )

        dispatch({ 
            type: EDIT_APPOINTMENT_SUCCESS, 
            payload: data 
        })

    } catch (error) {
        dispatch({ 
            type: EDIT_APPOINTMENT_FAIL, 
            payload: error.response && error.response.data.detail
                ? error.response.data.detail
                : error.message,
        })
    }
}

export const deleteAppointments = (appointmentId) => async (dispatch, getState) => {
    try {
        dispatch({ type: DELETE_APPOINTMENT_REQUEST })

        const {
        userLogin: { userInfo },
        } = getState()

        const config = {
        headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${userInfo.token}`,
        }}

        const { data } = await axios.delete(
        `/api/appointments/${appointmentId}/delete_app/`,
        config
        )

        dispatch({
        type: DELETE_APPOINTMENT_SUCCESS,
        payload: data 
        })

    } catch (error) {
        dispatch({
        type: DELETE_APPOINTMENT_FAIL,
        payload:
            error.response && error.response.data.message
            ? error.response.data.message
            : error.message,
        })
    }
}