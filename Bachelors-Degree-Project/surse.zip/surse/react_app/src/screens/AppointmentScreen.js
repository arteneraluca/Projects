import React, {useEffect} from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import Loader from '../components/Loader'
import Message from '../components/Message'
import AppointmentTable from '../components/AppointmentTable'
import Calendar from '../components/Calendar'
import { listMyAppointments } from '../actions/appointmentActions'

function AppointmentScreen() {

    const navigate = useNavigate()
  
    const dispatch = useDispatch()

    const appointmentList = useSelector(state => state.appointmentList)
    const { loading, error, appointments } = appointmentList
      
    const userLogin = useSelector(state => state.userLogin)
    const { userInfo } = userLogin
    
    useEffect(() => {
      if(userInfo) {

        dispatch(listMyAppointments())

      } else {
        navigate('/login')
      }
      
    }, [dispatch, navigate, userInfo])

    const handleScrollToCalendar = () => {
      const calendarElement = document.getElementById('calendar-container');
      calendarElement.scrollIntoView({ behavior: 'smooth' });
    }
    
    return (
        <div>
            <h1 style={{ marginTop: '20px'}}>Appointments</h1>
            {loading
                ? (<Loader />)
                : error
                    ? (<Message variant='danger'>{error}</Message>)
                    : (
                      <div>
                        <div style={{ marginTop: '20px' }}>
                          <button onClick={handleScrollToCalendar}>Go to Calendar</button>
                        </div>
                        <div>
                          <AppointmentTable
                            user = {userInfo}
                            appointments={appointments}
                          />
                        </div>

                        <div id="calendar-container" style={{marginTop: '100px'}}>
                          <Calendar 
                            appointments = {appointments}
                            user = {userInfo}
                          />
                        </div>
                      </div>
                    )}
        </div>
    )
}

export default AppointmentScreen
