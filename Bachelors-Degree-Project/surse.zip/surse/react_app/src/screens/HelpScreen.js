import React from 'react'
import { Container, Row, Col } from 'react-bootstrap'
import { Link } from 'react-router-dom'

function HelpScreen() {
  return (
    
    <Container>
      <Link to='/' className='btn btn-light my-3'> Inapoi </Link>
      <Row>
        <Col md={6}>
          <h2>For Clients</h2>
          <p>Instructions for clients on how to use the app:</p>
          <ul>
            <li>Step 1: Sign up for an account.</li>
            <li>Step 2: Browse available handymen.</li>
            <li>Step 3: Select a handyman and leave a review or make an appointment.</li>
            <li>Step 4: Wait for the response from him.</li>
            <li>Step 5: Manage appointments in your account.</li>
          </ul>
          <div className="embed-responsive embed-responsive-16by9">
            <iframe
              title="Client Tutorial"
              className="embed-responsive-item"
              style={{ marginTop: '20px' }}
              src="https://www.youtube.com/embed/"
              allowFullScreen
            ></iframe>
          </div>
        </Col>

        <Col md={6}>
          <h2>For Handymen</h2>
          <p>Instructions for handymen on how to use the app:</p>
          <ul>
            <li>Step 1: Sign up for an account as a handyman.</li>
            <li>Step 2: Set up your profile and services.</li>
            <li>Step 3: Manage bookings and appointments.</li>
          </ul>
          <div className="embed-responsive embed-responsive-16by9">
            <iframe
              title="Handymen Tutorial"
              className="embed-responsive-item"
              style={{ marginTop: '20px' }}
              src="https://www.youtube.com/embed/"
              allowFullScreen
            ></iframe>
          </div>
        </Col>
      </Row>
    </Container>
  )
}

export default HelpScreen
