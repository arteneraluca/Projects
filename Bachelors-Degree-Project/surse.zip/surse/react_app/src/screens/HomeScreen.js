import React, {useState, useEffect} from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Container, Row, Col } from 'react-bootstrap'
import { useLocation} from 'react-router-dom'
import Mester from '../components/Mester'
import Loader from '../components/Loader'
import Message from '../components/Message'
import Paginate from '../components/Paginate'
import { listMesteri } from '../actions/mesterActions'
import SearchBox from '../components/SearchBox'
import MesteriCarousel from '../components/MesteriCarousel'

function HomeScreen() {

  const location = useLocation()
  const dispatch = useDispatch()
  const mesterList = useSelector(state => state.mesterList)
  const {error, loading, mesteri, page, pages} = mesterList

  let keyword = location.search

  useEffect(() => {
    
    dispatch(listMesteri(keyword))

  }, [dispatch, keyword])

  return (
    <div>
      <Container>
        <SearchBox />
      </Container>

      {!keyword &&
      <Container style={{ marginTop: '40px' }}>
        <MesteriCarousel />
      </Container>}  

      <Container style={{ marginTop: '40px' }}>
        {!keyword && <h1>Meșteri noi</h1>}
        {loading ? < Loader/>
          : error ? <Message variant='danger'>{error}</Message>
            :
            <div>
              <Row>
              {mesteri?.map(mester => (
                  <Col key={mester._id} sm={12} md={6} lg={4} xl={3}>
                    <Mester mester = {mester} />
                  </Col>
              ))}
              </Row>
              <Paginate page={page} pages={pages} keyword={keyword}/>
            </div>
        }
      </Container>
    </div>
  )
}

export default HomeScreen
