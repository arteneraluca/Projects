import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Form, Button, Row, Col, Table } from 'react-bootstrap'
import { useDispatch, useSelector } from 'react-redux'
import axios from 'axios'
import Loader from '../components/Loader'
import Message from '../components/Message'
import { getUserDetails, updateUserProfile } from '../actions/userActions'
import { USER_UPDATE_PROFILE_RESET } from '../constants/userConstants'

function ProfileScreen() {

    const navigate = useNavigate()

    const [name, setName] = useState('')
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [confirmPassword, setConfirmPassword] = useState('')
    const [message, setMessage] = useState('')
    const [showChangePassword, setShowChangePassword] = useState(false)
    const [uploading, setUploading] = useState(false)
    const [categorie, setCategorie] = useState('')
    const [locatie, setLocatie] = useState('')
    const [descriere, setDescriere] = useState('')

    const dispatch = useDispatch()

    const userDetails = useSelector(state => state.userDetails)
    const { error, loading, user } = userDetails

    const userLogin = useSelector(state => state.userLogin)
    const { userInfo } = userLogin

    const userUpdateProfile = useSelector(state => state.userUpdateProfile)
    const { success } = userUpdateProfile

    useEffect(() => {
        if (!userInfo) {
            navigate('/login')
        } else {

            if (!user || !user.name || success) {
                dispatch({ type: USER_UPDATE_PROFILE_RESET })
                console.log('USER_UPDATE_PROFILE_RESET userInfo', userInfo)
                dispatch(getUserDetails())
                // console.log('AFTER UPDATE GET DETAILS', userInfo, user)
            } else {
                setName(user.name)
                setEmail(user.email)

                if (userInfo && userInfo.isMester){
                    setCategorie(user.categorie)
                    setLocatie(user.locatie)
                    setDescriere(user.descriere)
                }
            }
        }
    }, [dispatch, navigate, userInfo, user, success])

    const submitHandler = (e) => {
        e.preventDefault()

        if (password != confirmPassword) {
            setMessage('Passwords do not match')
        } else {
            const userData = {
                id: user.user,
                name,
                email,
                password,
            }

            if (userInfo && userInfo.isMester) {
                userData.categorie = categorie
                userData.locatie = locatie
                userData.descriere = descriere
            }

            dispatch(updateUserProfile(userData))
            setMessage('')
        }

    }

    const uploadFileHandler = async (e) => {
        const file = e.target.files[0]
        
        const formData = new FormData()

        formData.append('image', file)
        formData.append('user_id', userInfo.id)

        setUploading(true)

        try{
            const config = {
                headers:{
                    'Content-Type':'multipart/form-data'
                }
            }

            const {data} = await axios.post('/api/users/upload/', formData, config)

            setUploading(false)
            dispatch(getUserDetails())

        }catch(error){
            setUploading(false)
            console.error('Error uploading profile image:', error)
        }
    }

    return (
        <div>
        <Row>
            <Col md={4} style={{ marginTop: '20px' }}>
            <h2>User Profile</h2>
                <Form.Group> 

                <div>
                    <Form.Label>Change photo</Form.Label>
                        <Form.Control type='file'
                            id="profileImage"
                            label="Change Photo"
                            onChange={uploadFileHandler}
                            accept="image/*"
                        />
                    {uploading && <Loader />}
                </div>

                    {user && user.profileImage && (
                        <img src={user.profileImage} alt={user.name} className="rounded-circle mb-3" style={{ display: 'block', margin: 'auto', width: '250px', height: '250px', marginTop: '20px' }}/>
                    )}
                    
                </Form.Group>

            </Col>

            <Col md={8} style={{ marginTop: '60px' }}>

                {/* <Message variant='warning'>If you update your data you will need to log back in.</Message> */}
                {message && <Message variant='danger'>{message}</Message>}
                {error && <Message variant='danger'>{error}</Message>}
                {loading && <Loader />}

                <Form onSubmit={submitHandler} >
                    <Row>
                        <Col>
                            <Form.Group controlId='name'>
                                <Form.Label>Name</Form.Label>
                                <Form.Control
                                    required
                                    type='name'
                                    placeholder='Enter name'
                                    value={name}
                                    onChange={(e) => setName(e.target.value)}
                                >
                                </Form.Control>
                            </Form.Group>

                            <Form.Group controlId='email'>
                                <Form.Label>Email Address</Form.Label>
                                <Form.Control
                                    required
                                    type='email'
                                    placeholder='Enter Email'
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                >
                                </Form.Control>
                            </Form.Group>

                            {showChangePassword && (
                            <>
                                <Form.Group controlId='password'>
                                    <Form.Label>Password</Form.Label>
                                    <Form.Control
                                        type='password'
                                        placeholder='Enter Password'
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                    >
                                    </Form.Control>
                                </Form.Group>

                                <Form.Group controlId='passwordConfirm'>
                                    <Form.Label>Confirm Password</Form.Label>
                                    <Form.Control
                                        type='password'
                                        placeholder='Confirm Password'
                                        value={confirmPassword}
                                        onChange={(e) => setConfirmPassword(e.target.value)}
                                    >
                                    </Form.Control>
                                </Form.Group>
                            </>
                            )}
                            
                            <Button variant='light' style={{ marginTop: '20px'}} onClick={() => setShowChangePassword(!showChangePassword)}>
                                {showChangePassword ? 'Hide Change Password' : 'Change Password'}
                            </Button>
                        </Col>

                        {userInfo && userInfo.isMester && (
                            <Col>
                                <Form.Group controlId='categorie'>
                                    <Form.Label>Categorie</Form.Label>
                                    <Form.Control
                                        required
                                        type='categorie'
                                        placeholder='Enter categorie'
                                        value={categorie}
                                        onChange={(e) => setCategorie(e.target.value)}
                                    >
                                    </Form.Control>
                                </Form.Group>

                                <Form.Group controlId='locatie'>
                                    <Form.Label>Locatie</Form.Label>
                                    <Form.Control
                                        required
                                        type='locatie'
                                        placeholder='Enter locatie'
                                        value={locatie}
                                        onChange={(e) => setLocatie(e.target.value)}
                                    >
                                    </Form.Control>
                                </Form.Group>

                                <Form.Group controlId='descriere'>
                                    <Form.Label>Descriere</Form.Label>
                                    <Form.Control
                                        required
                                        as='textarea'
                                        row='10'
                                        type='descriere'
                                        placeholder='Enter descriere'
                                        value={descriere}
                                        onChange={(e) => setDescriere(e.target.value)}
                                    >
                                    </Form.Control>
                                </Form.Group>
                            </Col>
                        )}
                        <Button type='submit' variant='primary' style={{ marginTop: '20px', marginBottom: '20px'}}>
                            Update
                        </Button>
                    </Row> 
                </Form>
            </Col>
        </Row>

        </div>
    )
}

export default ProfileScreen