import React, { useState, useEffect } from 'react'
import { Link, useLocation, useNavigate} from 'react-router-dom'
import { Form, Button, Row, Col } from 'react-bootstrap'
import { useDispatch, useSelector } from 'react-redux'
import Loader from '../components/Loader'
import Message from '../components/Message'
import FormContainer from '../components/FormContainer'
import { register } from '../actions/userActions'

function RegisterScreen({}) {

    const location = useLocation()
    const navigate = useNavigate()

    const [name, setName] = useState('')
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [confirmPassword, setConfirmPassword] = useState('')
    const [message, setMessage] = useState('')
    const [account_type, setAccountType] = useState('customer')
    const [categorie, setCategorie] = useState('')
    const [locatie, setLocatie] = useState('')
    const [descriere, setDescriere] = useState('')

    const dispatch = useDispatch()

    const redirect = location.search ? location.search.split('=')[1] : '/'

    const userRegister = useSelector(state => state.userRegister)
    const { error, loading, userInfo } = userRegister

    useEffect(() => {
        if (userInfo) {
            navigate(redirect)
        }
    }, [navigate, userInfo, redirect])

    const submitHandler = (e) => {
        e.preventDefault()

        if (password != confirmPassword) {
            setMessage('Passwords do not match')
        } else {
            const extraData = account_type === 'mester' ? { categorie: categorie, locatie: locatie, descriere: descriere } : {}
            dispatch(register(name, email, password, account_type, extraData))
        }

    }

    return (
        <FormContainer>
            <h1>Sign Up</h1>
            {message && <Message variant='danger'>{message}</Message>}
            {error && <Message variant='danger'>{error}</Message>}
            {loading && <Loader />}
            <Form onSubmit={submitHandler}>

                <Form.Group controlId='name'>
                    <Form.Label>Name</Form.Label>
                    <Form.Control
                        required
                        type='name'
                        placeholder='Enter name'
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                    >
                    </Form.Control>
                </Form.Group>

                <Form.Group controlId='email'>
                    <Form.Label>Email Address</Form.Label>
                    <Form.Control
                        required
                        type='email'
                        placeholder='Enter Email'
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    >
                    </Form.Control>
                </Form.Group>

                <Form.Group controlId='password'>
                    <Form.Label>Password</Form.Label>
                    <Form.Control
                        required
                        type='password'
                        placeholder='Enter Password'
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    >
                    </Form.Control>
                </Form.Group>

                <Form.Group controlId='passwordConfirm'>
                    <Form.Label>Confirm Password</Form.Label>
                    <Form.Control
                        required
                        type='password'
                        placeholder='Confirm Password'
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                    >
                    </Form.Control>
                </Form.Group>

                <Form.Group controlId='account_type'>
                    <Form.Label>What do you want to be?</Form.Label>
                    <div>
                        <Form.Check
                            type='radio'
                            id='customer'
                            label='Customer'
                            value='customer'
                            checked={account_type === 'customer'}
                            onChange={(e) => setAccountType(e.target.value)}
                        />
                        <Form.Check
                            type='radio'
                            id='mester'
                            label='Mester'
                            value='mester'
                            checked={account_type === 'mester'}
                            onChange={(e) => setAccountType(e.target.value)}
                        />
                    </div>
                </Form.Group>

                {account_type === 'mester' && (
                    <>
                        <Form.Group controlId='categorie'>
                            <Form.Label>Categoria de servicii oferite</Form.Label>
                            <Form.Control
                                type='text'
                                placeholder='Enter category'
                                value={categorie}
                                onChange={(e) => setCategorie(e.target.value)}
                            ></Form.Control>
                        </Form.Group>

                        <Form.Group controlId='locatie'>
                            <Form.Label>Location</Form.Label>
                            <Form.Control
                                type='text'
                                placeholder='Enter location'
                                value={locatie}
                                onChange={(e) => setLocatie(e.target.value)}
                            ></Form.Control>
                        </Form.Group>

                        <Form.Group controlId='descriere'>
                            <Form.Label>Description</Form.Label>
                            <Form.Control
                                as='textarea'
                                row='5'
                                placeholder='Enter description'
                                value={descriere}
                                onChange={(e) => setDescriere(e.target.value)}
                            ></Form.Control>
                        </Form.Group>
                    </>
                )}

                <Button type='submit' variant='primary' style={{ marginTop: '20px' }}>
                    Register
                </Button>

            </Form>

            <Row className='py-3'>
                <Col>
                    Have an Account? <Link
                        to={redirect ? `/login?redirect=${redirect}` : '/login'}>
                        Sign In
                        </Link>
                </Col>
            </Row>
        </FormContainer>
    )
}

export default RegisterScreen