import React, {useState, useEffect} from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link, useParams } from 'react-router-dom'
import { Row, Col, Image, ListGroup, Button, Card, Form } from 'react-bootstrap'
import Rating from '../components/Rating'
import Loader from '../components/Loader'
import Message from '../components/Message'
import { listMesterDetails, createMesterReview } from '../actions/mesterActions'
import { createAppointment } from '../actions/appointmentActions'
import { MESTER_CREATE_REVIEW_RESET } from '../constants/mesterConstants'
import { REQUEST_APPOINTMENT_RESET } from '../constants/appointmentConstants'
import Calendar from '../components/Calendar'
import { listMyAppointments } from '../actions/appointmentActions'

function MesterScreen() {
  const {id} = useParams()

  const [rating, setRating] = useState(0)
  const [comment, setComment] = useState('')
  const [date, setDate] = useState('')
  const [time_slot, setTimeSlot] = useState('')
  const [address, setAddress] = useState('')
  const [description, setDescription] = useState('')

  const dispatch = useDispatch()

  const mesterDetails = useSelector(state => state.mesterDetails)
  const {loading, error, mester} = mesterDetails

  // const appointmentList = useSelector(state => state.appointmentList)
  // const { appointments } = appointmentList
  // console.log('appoint', appointments)
  // console.log('mester', mester)

  const requestAppointment = useSelector(state => state.requestAppointment)
  const {
    loading: loadingAppointment,
    error: errorAppointment,
    success: successAppointment,
  } = requestAppointment

  const userLogin = useSelector(state => state.userLogin)
  const { userInfo } = userLogin

  const mesterReviewCreate = useSelector(state => state.mesterReviewCreate)
  const {
      loading: loadingMesterReview,
      error: errorMesterReview,
      success: successMesterReview,
  } = mesterReviewCreate

  useEffect(() => {
  //   if(userInfo){
  //     dispatch(listMyAppointments())
  //   }

    if (successMesterReview) {
      setRating(0)
      setComment('')
      dispatch({ type: MESTER_CREATE_REVIEW_RESET })
    }

    dispatch(listMesterDetails(id))

    if (successAppointment) {
      setDate('')
      setTimeSlot('')
      setAddress('')
      setDescription('')
      dispatch({ type: REQUEST_APPOINTMENT_RESET })
    }

  }, [dispatch, userInfo, id, successMesterReview, successAppointment])

  const submitHandler = (e) => {
    e.preventDefault()
    dispatch(createMesterReview(
        id, {
        rating,
        comment
    }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()

    const appointmentData = {
       date, 
       time_slot,
       address,
       description
    }

    dispatch(createAppointment(id, appointmentData))
  }

  // const handleScrollToCalendar = () => {
  //   const calendarElement = document.getElementById('calendar-container');
  //   calendarElement.scrollIntoView({ behavior: 'smooth' });
  // }

  return (
    <div>
      <Link to='/' className='btn btn-light my-3'> Inapoi </Link>

      {
        loading ? <Loader />
        : error ? <Message variant='danger'>{error}</Message>
        : (
          <div>
            <Row>
              <Col md = {6}>
                <Image src={mester.profileImage} alt={mester.name} fluid/>
              </Col>

              <Col md={6}>
                <ListGroup variant="flush">
                  <ListGroup.Item>
                    <h3>{mester.name}</h3>
                    <strong>Location: {mester.locatie}</strong>
                  </ListGroup.Item>

                  <ListGroup.Item>
                    <Rating value={mester.rating} text={`(${mester.totalReviews} reviews)`} />
                  </ListGroup.Item>

                  <ListGroup.Item>
                    <h5>{mester.categorie}</h5>
                  </ListGroup.Item>

                  <ListGroup.Item>
                    {mester.descriere} 
                  </ListGroup.Item>
                </ListGroup>
              </Col>

            </Row>

            <Row style={{ marginTop: '50px' }}>
              <Col md={6}>
                <h4>Reviews</h4>
                {mester.reviews.length === 0 && <Message variant='info'>No Reviews</Message>}

                <ListGroup variant='flush'>
                  {mester.reviews.map((review) => (
                  <ListGroup.Item key={review._id}>
                    <strong>{review.nume}</strong>
                    <Rating value={review.rating} />
                    <p>{review.createdAt.substring(0, 10)}</p>
                    <p>{review.comment}</p>
                  </ListGroup.Item>
                  ))}

                  <ListGroup.Item>
                    <h4>Write a review</h4>

                    {loadingMesterReview && <Loader />}
                    {successMesterReview && <Message variant='success'>Review Submitted</Message>}
                    {errorMesterReview && <Message variant='danger'>{errorMesterReview}</Message>}

                    {userInfo ? (
                      <Form onSubmit={submitHandler}>
                        <Form.Group controlId='rating'>
                          <Form.Label>Rating</Form.Label>
                          <Form.Control
                            as='select'
                            value={rating}
                            onChange={(e) => setRating(e.target.value)}
                          >
                            <option value=''>Select rating...</option>
                            <option value='1'>1 - Poor</option>
                            <option value='2'>2 - Fair</option>
                            <option value='3'>3 - Good</option>
                            <option value='4'>4 - Very Good</option>
                            <option value='5'>5 - Excellent</option>
                          </Form.Control>
                        </Form.Group>

                        <Form.Group controlId='comment'>
                          <Form.Label>Review</Form.Label>
                          <Form.Control
                              as='textarea'
                              row='5'
                              value={comment}
                              onChange={(e) => setComment(e.target.value)}
                          ></Form.Control>
                        </Form.Group>

                        <Button
                          disabled={loadingMesterReview}
                          type='submit'
                          variant='primary'
                          style={{ marginTop: '20px' }}
                        >
                          Submit
                        </Button>

                      </Form>
                    ) 
                    : (
                        <Message variant='info'>Please <Link to='/login'>login</Link> to write a review</Message>
                      )}
                  </ListGroup.Item>
                </ListGroup>

              </Col>

              <Col md={6}>
              {/* <button onClick={handleScrollToCalendar}>Go to Calendar</button> */}
              <h4 style={{marginTop: '20px'}}>Make Appointment</h4>

                {loadingAppointment && <Loader />}
                {successAppointment && <Message variant='success'>Appointment submitted</Message>}
                {errorAppointment && <Message variant='danger'>{errorAppointment}</Message>}

                {userInfo ? (
                  <Form onSubmit={handleSubmit}>

                    <Form.Group controlId='date'>
                      <Form.Label>Date</Form.Label>
                      <Form.Control
                          required
                          type='date'
                          placeholder='Choose date'
                          value={date}
                          onChange={(e) => setDate(e.target.value)}
                      >
                      </Form.Control>
                    </Form.Group>

                    <Form.Group controlId='time-slot'>
                      <Form.Label>When?</Form.Label>
                      <Form.Control
                        as='select'
                        value={time_slot}
                        onChange={(e) => setTimeSlot(e.target.value)}
                      >
                        <option value=''>Select time slot...</option>
                        <option value='08:00 - 14:00'>08:00 - 14:00</option>
                        <option value='14:00 - 20:00'>14:00 - 20:00</option>
                        <option value='anytime'>Anytime</option>
                      </Form.Control>
                    </Form.Group>

                    <Form.Group controlId='address'>
                      <Form.Label>Address</Form.Label>
                      <Form.Control
                          required
                          type='text'
                          placeholder='Enter address'
                          value={address}
                          onChange={(e) => setAddress(e.target.value)}
                      >
                      </Form.Control>
                    </Form.Group>

                    <Form.Group controlId='description'>
                      <Form.Label>Descriere job</Form.Label>
                      <Form.Control
                          as='textarea'
                          row='5'
                          value={description}
                          onChange={(e) => setDescription(e.target.value)}
                      ></Form.Control>
                    </Form.Group>

                    <Button
                      disabled={loadingAppointment}
                      type='submit'
                      variant='primary'
                      style={{ marginTop: '20px' }}
                    >
                      Make Appointment
                    </Button>

                  </Form>
                ) 
                : (
                    <Message variant='info'>Please <Link to='/login'>login</Link> to make an appointment</Message>
                  )}
              </Col>
            </Row>

            {/* <Row>
              <div id="calendar-container" style={{marginTop: '100px'}}>
                <Calendar 
                  appointments = {appointments}
                  user = {mester}
                />
              </div>
            </Row> */}
          </div>
        )
      }
    </div>
  )
}

export default MesterScreen

