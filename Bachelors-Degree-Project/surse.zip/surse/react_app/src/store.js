import { createStore, combineReducers, applyMiddleware } from 'redux'
import {thunk} from 'redux-thunk';
import { composeWithDevTools } from 'redux-devtools-extension'
import { mesterListReducer, mesterDetailsReducer, mesterReviewCreateReducer, mesterTopRatedReducer } from './reducers/mesterReducers'
import { userLoginReducer, userRegisterReducer, userDetailsReducer, userUpdateProfileReducer } from './reducers/userReducers'
import { appointmentListReducer, requestAppointmentReducer, acceptAppointmentReducer, rejectAppointmentReducer, editAppointmentReducer } from './reducers/appointmentReducers'

const reducer = combineReducers({
    mesterList: mesterListReducer,
    mesterDetails: mesterDetailsReducer,
    mesterReviewCreate: mesterReviewCreateReducer,
    mesterTopRated: mesterTopRatedReducer,

    userLogin: userLoginReducer,
    userRegister: userRegisterReducer,
    userDetails: userDetailsReducer,
    userUpdateProfile: userUpdateProfileReducer,

    appointmentList: appointmentListReducer,
    requestAppointment: requestAppointmentReducer,
    acceptAppointment: acceptAppointmentReducer,
    rejectAppointment: rejectAppointmentReducer,
    editAppointment: editAppointmentReducer,

})

const userInfoFromStorage = localStorage.getItem('userInfo') ?
    JSON.parse(localStorage.getItem('userInfo')) : null

const initialState = {
    userLogin: {userInfo: userInfoFromStorage}
}

const middleware = [thunk]

const store = createStore(reducer, initialState, composeWithDevTools(applyMiddleware(...middleware)))

export default store