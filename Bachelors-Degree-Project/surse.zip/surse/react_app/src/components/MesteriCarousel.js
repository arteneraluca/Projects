import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import { Carousel, Image } from 'react-bootstrap'
import Loader from './Loader'
import Message from './Message'
import Rating from './Rating'
import { listTopMesteri } from '../actions/mesterActions'

function MesteriCarousel() {
    const dispatch = useDispatch()

    const mesterTopRated = useSelector(state => state.mesterTopRated)
    const { error, loading, mesteri } = mesterTopRated

    useEffect(() => {
        dispatch(listTopMesteri())
    }, [dispatch])

    return (loading ? <Loader />
        : error
            ? <Message variant='danger'>{error}</Message>
            : (
                <Carousel pause='hover' >
                    {mesteri.map(mester => (
                        <Carousel.Item key={mester._id}>
                            <Link to={`/mester/${mester._id}`}>
                                <Image src={mester.profileImage} alt={mester.name} fluid />
                                <Carousel.Caption className='carousel.caption'>
                                    <h4>{mester.name} ({mester.categorie}) - {mester.locatie}</h4>
                                    <h4><Rating value={mester.rating}/></h4>
                                    
                                </Carousel.Caption>
                            </Link>
                        </Carousel.Item>
                    ))}
                </Carousel>
            )

    )
}

export default MesteriCarousel