import React from 'react'
import { Card } from 'react-bootstrap'
import Rating from './Rating'
import { Link } from 'react-router-dom'

function Mester({mester}) {
  return (
    <Card className='my-3 p-3 rounded'>
      <Link to={`/mester/${mester._id}`}>
        <Card.Img src={mester.profileImage} />
      </Link>

      <Card.Body>
        <Link to={`/mester/${mester._id}`}>
            <Card.Title as="div">
                <strong>{mester.name}</strong>
            </Card.Title>
        </Link>

        <Card.Text as="div">
            <div className='my-3'>
               <Rating value={mester.rating} text={`(${mester.totalReviews} reviews)`} />
            </div>

            <div className='my-3'>
                Location: {mester.locatie}
            </div>
        </Card.Text>

        <Card.Text as="h5">
            {mester.categorie}
        </Card.Text>
      </Card.Body>
    </Card>
  )
}

export default Mester
