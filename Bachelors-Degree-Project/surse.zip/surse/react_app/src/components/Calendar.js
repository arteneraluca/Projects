import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';

function Calendar({appointments, user}) {

    const [calendarEvents, setCalendarEvents] = useState([])

    useEffect(() => {
        if (appointments) {

            const today = new Date()
            const acceptedAppointments = appointments.filter(appointment => appointment.accepted)

            const sortedAppointments = acceptedAppointments.sort((a, b) => {
                return new Date(a.start_time) - new Date(b.start_time);
            })

            const events = sortedAppointments.map(appointment => {
                const eventDate = new Date(appointment.date)
                const isPast = eventDate < today

                if (user && user.isMester){
                    return {
                        title: `${appointment.start_time} - ${appointment.name_customer}`,
                        start: appointment.date,
                        classNames: isPast ? 'past-appointment' : ''
                    }
                } else {
                    return {
                        title: `${appointment.start_time} - ${appointment.name_mester}`,
                        start: appointment.date,
                        classNames: isPast ? 'past-appointment' : ''
                    }
                }
            })
            setCalendarEvents(events)
        }
    }, [appointments])

    return (
        <div>
        <FullCalendar
            plugins = {[dayGridPlugin, timeGridPlugin]}
            initialView = "dayGridMonth"
            events = {calendarEvents}
        >
        </FullCalendar>
        </div>
    )
}

export default Calendar
