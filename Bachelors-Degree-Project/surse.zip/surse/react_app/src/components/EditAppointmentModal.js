import React, {useState, useEffect} from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Modal, Button, Form } from 'react-bootstrap'
import { editAppointments } from '../actions/appointmentActions'
import { EDIT_APPOINTMENT_RESET } from '../constants/appointmentConstants'

function EditAppointmentModal({show, handleClose, appointment, user}) {

    const [date, setDate] = useState('')
    const [time_slot, setTimeSlot] = useState('')
    const [address, setAddress] = useState('')
    const [description, setDescription] = useState('')

    const dispatch = useDispatch()

    const editAppointment = useSelector(state => state.editAppointment)
    const {success: successAppointment} = editAppointment

    useEffect(() => {
  
        if (successAppointment) {
            setDate('')
            setTimeSlot('')
            setAddress('')
            setDescription('')
            dispatch({ type: EDIT_APPOINTMENT_RESET })
        } else {
            setDate(appointment.date)
            setTimeSlot(appointment.time_slot)
            setAddress(appointment.address)
            setDescription(appointment.description)
        }
        
      }, [dispatch, successAppointment])

    const submitHandler = (e) => {
        e.preventDefault()

        const appointmentData = {
            date, 
            time_slot,
            address,
            description,
            ...user
        }

        dispatch(editAppointments(appointment._id, appointmentData))
        window.location.reload()
    }

    return (
        <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
                    <Modal.Title>Edit</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Form onSubmit={submitHandler}>

                    <Form.Group controlId='date'>
                    <Form.Label>Date</Form.Label>
                    <Form.Control
                        required
                        type='date'
                        placeholder='Choose date'
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                    >
                    </Form.Control>
                    </Form.Group>

                    <Form.Group controlId='time-slot'>
                    <Form.Label>When?</Form.Label>
                    <Form.Control
                        as='select'
                        value={time_slot}
                        onChange={(e) => setTimeSlot(e.target.value)}
                    >
                        <option value=''>Select time slot...</option>
                        <option value='08:00 - 14:00'>08:00 - 14:00</option>
                        <option value='14:00 - 20:00'>14:00 - 20:00</option>
                        <option value='anytime'>Anytime</option>
                    </Form.Control>
                    </Form.Group>

                    <Form.Group controlId='address'>
                    <Form.Label>Address</Form.Label>
                    <Form.Control
                        required
                        type='text'
                        placeholder='Enter address'
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                    >
                    </Form.Control>
                    </Form.Group>

                    <Form.Group controlId='description'>
                    <Form.Label>Descriere job</Form.Label>
                    <Form.Control
                        as='textarea'
                        row='5'
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                    ></Form.Control>
                    </Form.Group>

                    <Button
                    type='submit'
                    variant='primary'
                    style={{ marginTop: '20px' }}
                    >
                        Edit Appointment
                    </Button>

                    </Form>
                
            </Modal.Body>
            <Modal.Footer>
                <Button variant="secondary" onClick={handleClose}>
                    Close
                </Button>
            </Modal.Footer>
        </Modal>
    )
}

export default EditAppointmentModal
