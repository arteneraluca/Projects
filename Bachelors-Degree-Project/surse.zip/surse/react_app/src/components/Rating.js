import React from 'react'

function Rating({value, text}) {
  return (
    <div className='rating'>
      <span><strong>{value}</strong></span>
      <span>
        <i className={
            value>=1
            ? 'fas fa-circle'
            : value >=0.5
            ? 'fas fa-circle-half-stroke'
                : 'far fa-circle'
        }></i>
      </span>

      <span>
        <i className={
            value>=2
            ? 'fas fa-circle'
            : value >=1.5
            ? 'fas fa-circle-half-stroke'
                : 'far fa-circle'
        }></i>
      </span>

      <span>
        <i className={
            value>=3
            ? 'fas fa-circle'
            : value >=2.5
            ? 'fas fa-circle-half-stroke'
                : 'far fa-circle'
        }></i>
      </span>

      <span>
        <i className={
            value>=4
            ? 'fas fa-circle'
            : value >=3.5
            ? 'fas fa-circle-half-stroke'
                : 'far fa-circle'
        }></i>
      </span>

      <span>
        <i className={
            value>=5
            ? 'fas fa-circle'
            : value >=4.5
            ? 'fas fa-circle-half-stroke'
                : 'far fa-circle'
        }></i>
      </span>

      <div>{text && text}</div>
    </div>
  )
}

export default Rating
