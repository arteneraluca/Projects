import React, {useState, useEffect} from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Row, Col, Modal, Button, Form } from 'react-bootstrap'
import { acceptAppointments, rejectAppointments } from '../actions/appointmentActions'
import { ACCEPT_APPOINTMENT_RESET } from '../constants/appointmentConstants'

function formatDate(date) {
    const options = { day: '2-digit', month: '2-digit', year: 'numeric' };
    return new Date(date).toLocaleDateString('en-GB', options);
}

function AppointmentDetailsModal({show, handleClose, appointment, user}) {

    const [startTime, setStartTime] = useState('')

    const dispatch = useDispatch()

    const acceptAppointment = useSelector(state => state.acceptAppointment)
    const { success: successAppointment } = acceptAppointment

    useEffect(() => {
  
          if (successAppointment) {
              setStartTime('')
              dispatch({ type: ACCEPT_APPOINTMENT_RESET })
            }
        
      }, [dispatch, successAppointment])

    const submitHandler = (e) => {
        e.preventDefault()

        dispatch(acceptAppointments(appointment._id, startTime))
        window.location.reload()
    }

    const handleReject = () => {
        dispatch(rejectAppointments(appointment._id, user))
        window.location.reload()
    }

    return (
        <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
                    <Modal.Title>Appointment Details</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Row>
                    <Col>
                        <p><strong>Status:</strong>
                            {appointment.accepted === false && appointment.rejected === false ? (
                                <i className='fas fa-check' style={{ color: 'orange', marginLeft: '20px' }}>Pending</i>
                            ) : appointment.accepted ? (
                                    <i className='fas fa-check' style={{ color: 'green', marginLeft: '20px' }}>Accepted</i>
                            ) : (
                                    <i className='fas fa-check' style={{ color: 'red', marginLeft: '20px' }}>Rejected</i>
                            )}
                        </p>

                        {user && user.isCustomer ? (
                            <div>
                                <strong>Nume mester:</strong>
                                <p>{appointment.name_mester}</p>
                            </div>
                        ) : (
                            <div>
                                <strong>Nume client:</strong>
                                <p>{appointment.name_customer}</p>
                            </div>
                        )}

                        <strong>Details:</strong>
                        <p>{appointment.description}</p>

                        <strong>Address:</strong>
                        <p>{appointment.address}</p>
                    </Col>

                    <Col>
                        <strong>Data:</strong>
                        <p>{formatDate(appointment.date)}</p>

                        <strong>Perioada preferata:</strong>
                        <p>{appointment.time_slot}</p>

                        {user && user.isCustomer ? (
                            appointment.accepted ? (
                                <div>
                                    <strong style={{ color: 'green'}}>Start time:</strong>
                                    <p style={{ color: 'green'}}>{appointment.start_time}</p>
                                </div>
                            ) : appointment.rejected ? (
                                <p style={{ color: 'red'}}>This appointment was rejected.</p>
                            ) : (
                                <p style={{ color: 'orange'}}>This appointment is pending approval.</p>
                            )

                        ) : (
                            appointment.accepted ? (
                                <div>
                                    <strong style={{ color: 'green'}}>Start time:</strong>
                                    <p style={{ color: 'green'}}>{appointment.start_time}</p>
                                </div>
                            ) : appointment.rejected ? (
                                <p style={{ color: 'red'}}>This appointment was rejected.</p>
                            ) : (
                                <Form onSubmit={submitHandler}>
                                        <Form.Group controlId='start_time'>
                                            <Form.Label>Start time</Form.Label>
                                            <Form.Control
                                                required
                                                type='time'
                                                placeholder='Choose time'
                                                value={startTime}
                                                onChange={(e) => setStartTime(e.target.value)}
                                            >
                                            </Form.Control>
                                        </Form.Group>

                                        <div>
                                            <Button type="submit" variant="success" style={{ marginTop: '20px' }}>Accept</Button>
                                            <Button type="button" variant="danger" onClick={handleReject} style={{ marginTop: '20px', marginLeft: '20px' }}>Reject</Button>
                                        </div>

                                    </Form>

                            )
                        )}
                    </Col>
                </Row>
                
            </Modal.Body>
            <Modal.Footer>
                <Button variant="secondary" onClick={handleClose}>
                    Close
                </Button>
            </Modal.Footer>
        </Modal>
    )
}

export default AppointmentDetailsModal
