import React, {useState} from 'react'
import { Button, Table } from 'react-bootstrap'
import { useDispatch } from 'react-redux'
import AppointmentDetailsModal from '../components/AppointmentDetailsModal'
import EditAppointmentModal from '../components/EditAppointmentModal'
import { deleteAppointments } from '../actions/appointmentActions'

function formatDate(date) {
    const options = { day: '2-digit', month: '2-digit', year: 'numeric' };
    return new Date(date).toLocaleDateString('en-GB', options);
}

function AppointmentTable({user, appointments}) {

    const dispatch = useDispatch()

    const[showModal, setShowModal] = useState(false)
    const[showEditModal, setShowEditModal] = useState(false)
    const[selectedAppointment, setSelectedAppointment] = useState(null)

    const handleShowModal = (appointment) => {
        setSelectedAppointment(appointment)
        setShowModal(true)
    }

    const handleEditShowModal = (appointment) => {
        setSelectedAppointment(appointment)
        setShowEditModal(true)
    }

    const handleCloseModal = () => {
        setSelectedAppointment(null)
        setShowModal(false)
    }

    const handleCloseEditModal = () => {
        setSelectedAppointment(null)
        setShowEditModal(false)
    }

    const handleDelete = (appointmentId) => {
        dispatch(deleteAppointments(appointmentId))
        window.location.reload()
    }

    return (
        <div>
            <Table striped bordered hover responsive className='table-sm' style={{ marginTop: '20px'}}>
                <thead>
                    <tr>
                        {user && user.isCustomer ? (
                            <th>MESTER</th>
                        ) : (
                            <th>CUSTOMER</th>
                        )}
                        <th>DATE</th>
                        <th>STATUS</th>
                        <th></th>
                    </tr>
                </thead>

                <tbody>
                    {appointments.map(appointment => (
                            <tr key={appointment._id}>
                            
                                {user && user.isCustomer ? (
                                    <td>{appointment.name_mester}</td>
                                ) : (
                                    <td>{appointment.name_customer}</td>
                                )}

                                <td>{formatDate(appointment.date)}</td>

                                <td>{appointment.accepted === false && appointment.rejected === false ? (
                                    <i className='fas fa-check' style={{ color: 'orange' }}>Pending</i>
                                ) : appointment.accepted ? (
                                        <i className='fas fa-check' style={{ color: 'green' }}>Accepted</i>
                                    ) : (
                                        <i className='fas fa-check' style={{ color: 'red' }}>Rejected</i>
                                    )}
                                </td>

                                <td className="d-flex justify-content-center">
                                    <Button 
                                        variant='light' 
                                        className='btn-sm'
                                        onClick={() => handleShowModal(appointment)}
                                        style={{ marginRight: '20px' }}
                                    >
                                        Details
                                    </Button>

                                    {user && user.isCustomer && !appointment.accepted && !appointment.rejected && (
                                        <div>
                                        <Button 
                                            variant='light'
                                            className='btn-sm'
                                            onClick={() => handleEditShowModal(appointment)}
                                        >
                                            <i className='fas fa-edit'></i>
                                        </Button>

                                        <Button 
                                            variant='danger'
                                            className='btn-sm'
                                            onClick={() => handleDelete(appointment._id)}
                                        >
                                            <i className='fas fa-trash'></i>
                                        </Button>
                                    </div>
                                    )}

                                </td>
                            </tr>
                    
                    ))}
                </tbody>
            </Table>

            {selectedAppointment && (
                <AppointmentDetailsModal
                    show={showModal}
                    handleClose={handleCloseModal}
                    appointment={selectedAppointment}
                    user = {user}
                />
            )}

            {selectedAppointment && (
                <EditAppointmentModal
                    show={showEditModal}
                    handleClose={handleCloseEditModal}
                    appointment={selectedAppointment}
                    user = {user}
                />
            )}

        </div>
    )
}

export default AppointmentTable
