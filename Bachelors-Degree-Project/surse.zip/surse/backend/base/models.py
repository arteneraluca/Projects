from django.db import models
from django.contrib.auth.models import User


class Customer(models.Model): 
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    profileImage = models.ImageField(null=True, blank=True)
    # locatie = models.CharField(max_length=200)
    _id = models.AutoField(primary_key=True, editable=False)

    def __str__(self):
        return self.user.first_name

class Mester(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    categorie = models.CharField(max_length=200)
    descriere = models.TextField()
    profileImage = models.ImageField(null = True, blank = True)
    locatie = models.CharField(max_length=200)
    rating = models.DecimalField(max_digits=2, decimal_places=1, default=0.0)
    totalReviews = models.IntegerField(default=0)
    _id = models.AutoField(primary_key=True, editable=False)

    def __str__ (self):
        return self.user.first_name

class Review(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    mester = models.ForeignKey(Mester, on_delete=models.CASCADE)
    comment = models.TextField()
    rating = models.IntegerField(default=0)
    nume = models.CharField(max_length=100, blank=True)
    createdAt = models.DateTimeField(auto_now_add=True)
    _id = models.AutoField(primary_key=True, editable=False)

    def __str__(self):
        return str(self.rating)

    def save(self, *args, **kwargs):
        if not self.nume:
            self.nume = self.user.username
        super().save(*args, **kwargs)

class Appointment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    mester = models.ForeignKey(Mester, on_delete=models.CASCADE)
    date = models.DateField()
    time_slot = models.CharField(max_length=20)  # 8:00 - 14:00, 14:00 - 20:00, anytime
    start_time = models.TimeField(null=True, blank=True)
    address = models.CharField(max_length=200)
    description = models.TextField()
    accepted = models.BooleanField(default=False)
    rejected = models.BooleanField(default=False)

    _id = models.AutoField(primary_key=True, editable=False)

    def __str__(self):
        return f"Appointment with {self.mester.user.first_name} on {self.date} at {self.time_slot}"
