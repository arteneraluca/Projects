from django.urls import path
from base.views import appointments_views as views

urlpatterns = [
    path('', views.getAppointments, name='appointments'),
    path('list_apps/', views.getListOfAppointments, name='list-appointments'),
    path('<str:pk>/request_app/', views.requestAppointment, name='request_appointment'),
    path('<str:pk>/accept_app/', views.acceptAppointment, name='accept_appointment'),
    path('<str:pk>/reject_app/', views.rejectAppointment, name='reject_appointment'),
    path('<str:pk>/edit_app/', views.editAppointment, name='edit_appointment'),
    path('<str:pk>/delete_app/', views.deleteAppointment, name='delete_appointment'),
]