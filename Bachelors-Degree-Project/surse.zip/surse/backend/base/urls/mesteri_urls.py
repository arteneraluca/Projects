from django.urls import path
from base.views import mesteri_views as views

urlpatterns = [
    path('', views.getMesteri, name='mesteri'),
    path('<str:pk>/reviews/', views.createMesterReview, name='create-review'),
    path('top/', views.getTopMesteri, name='top-mesteri'),
    path('<str:pk>/', views.getMester, name='mester'),
]