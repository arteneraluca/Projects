from django.urls import path
from base.views import customers_views as views

urlpatterns = [
    path('', views.getCustomers, name='customers'),
    path('<str:pk>/', views.getCustomer, name='customer'),
]