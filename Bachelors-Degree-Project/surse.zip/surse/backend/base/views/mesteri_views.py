from django.shortcuts import render
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

from base.models import Customer, Mester, Review
from base.serializers import UserSerializer, CustomerSerializer, MesterSerializer

@api_view(['GET'])
def getMesteri(request):
    query = request.query_params.get('keyword')
    if query == None:
        query = ''

    if query == '':
        mesteri = Mester.objects.filter(categorie__icontains=query)
    else:
        mesteri = Mester.objects.filter(categorie__icontains=query).order_by('-rating')

    page = request.query_params.get('page')
    paginator = Paginator(mesteri, 1)

    try:
        mesteri = paginator.page(page)
    except PageNotAnInteger:
        mesteri = paginator.page(1)
    except EmptyPage:
        mesteri = paginator.page(paginator.num_pages)

    if page == None:
        page = 1

    page = int(page)

    serializer = MesterSerializer(mesteri, many=True)
    return Response({'mesteri':serializer.data, 'page': page, 'pages': paginator.num_pages})

@api_view(['GET'])
def getTopMesteri(request):
    mesteri = Mester.objects.filter(rating__gte=4).order_by('-rating')[0:5]
    serializer = MesterSerializer(mesteri, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def getMester(request, pk):
    mester = Mester.objects.get(_id=pk)
    serializer = MesterSerializer(mester, many=False)
    return Response(serializer.data)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def createMesterReview(request, pk):
    user = request.user
    mester = Mester.objects.get(_id=pk)
    data = request.data

    user_serializer = UserSerializer(user)
    is_customer = user_serializer.data.get('isCustomer', False)

    if not is_customer:
        content = {'detail': 'Only customers can review a handyman.'}
        return Response(content, status=status.HTTP_403_FORBIDDEN)

    # 1 - Review already exists
    alreadyExists = Review.objects.filter(user=user, mester=mester).exists()
    if alreadyExists:
        content = {'detail': 'Handyman already reviewed.'}
        return Response(content, status=status.HTTP_400_BAD_REQUEST)

    # 2 - No Rating or 0
    elif data['rating'] == 0:
        content = {'detail': 'Please select a rating'}
        return Response(content, status=status.HTTP_400_BAD_REQUEST)

    # 3 - Create review
    else:
        review = Review.objects.create(
            user=user,
            mester=mester,
            nume=user.first_name,
            rating=data['rating'],
            comment=data['comment'],
        )

        reviews = mester.review_set.all()
        mester.totalReviews = len(reviews)

        total = 0
        for i in reviews:
            total += i.rating

        mester.rating = total / len(reviews)
        mester.save()

        return Response('Review Added')