from django.shortcuts import render
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status

from base.models import Customer, Mester, Review
from base.serializers import CustomerSerializer

@api_view(['GET'])
def getCustomers(request):
    customers = Customer.objects.all()
    serializer = CustomerSerializer(customers, many=True)
    return Response({'customers':serializer.data})

@api_view(['GET'])
def getCustomer(request, pk):
    customer = Customer.objects.get(_id=pk)
    serializer = CustomerSerializer(customer, many=False)
    return Response(serializer.data)