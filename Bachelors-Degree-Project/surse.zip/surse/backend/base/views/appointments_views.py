from django.shortcuts import render
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
import datetime

from base.models import Customer, Mester, Appointment
from base.serializers import UserSerializer, CustomerSerializer, MesterSerializer, AppointmentSerializer

@api_view(['GET'])
def getAppointments(request):
    appointments = Appointment.objects.all()
    serializer = AppointmentSerializer(appointments, many=True)
    return Response({'appointments':serializer.data})

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def requestAppointment(request, pk):

    data = request.data
    user = request.user
    mester = Mester.objects.get(_id = pk)
    date = data.get('date')

    user_serializer = UserSerializer(user)
    is_customer = user_serializer.data.get('isCustomer', False)

    if not is_customer:
        content = {'detail': 'Only customers can do appointments to a mester'}
        return Response(content, status=status.HTTP_403_FORBIDDEN)

    try:
        date = datetime.datetime.strptime(date, "%Y-%m-%d").date()
    except ValueError:
        return Response("Invalid date format. Use YYYY-MM-DD.", status=400)

    if date <= datetime.datetime.today().date():
        content = {'detail': 'Appointments must have dates starting tomorrow.'}
        return Response(content, status=400)

    existing_appointment = Appointment.objects.filter(
        user=user,
        mester=mester,
        date=date
    ).exists()

    if existing_appointment:
        content = {'detail': 'You have already made an appointment with this mester on the specified date.'}
        return Response(content, status=status.HTTP_400_BAD_REQUEST)

    appointment_data = {
        'user': user.pk,
        'mester': mester.pk,
        'date': date,
        'time_slot': data ['time_slot'],
        'address': data ['address'],
        'description': data ['description'],
        
    }

    serializer = AppointmentSerializer(data=appointment_data)

    if serializer.is_valid():
        serializer.save()
        content = {'detail': 'Appointment successfully requested.'}
        return Response(content, status=201)
    return Response(serializer.errors, status=400)

@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def acceptAppointment(request, pk):
    data = request.data
    user = request.user
    start_time = data.get("start_time")

    user_serializer = UserSerializer(user)
    is_mester = user_serializer.data.get('isMester', False)

    if not is_mester:
        content = {'detail': 'Only handymen can accept appointments.'}
        return Response(content, status=status.HTTP_403_FORBIDDEN)

    try:
        start_time = datetime.datetime.strptime(start_time, "%H:%M").time()
    except (ValueError, TypeError):
        return Response({"message": "Accepted Start Time is not valid."}, status=400)

    appointment = Appointment.objects.filter(_id=pk, mester=request.user.mester).first()
    if not appointment:
        return Response({"message": "Invalid Appointment."}, status=404)

    appointment.accepted = True
    appointment.start_time = start_time
    appointment.save()
    return Response({"message": "Appointment successfully accepted."}, status=200)

@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def rejectAppointment(request, pk):
    data = request.data
    user = request.user

    user_serializer = UserSerializer(user)
    is_mester = user_serializer.data.get('isMester', False)

    if not is_mester:
        content = {'detail': 'Only handymen can reject appointments.'}
        return Response(content, status=status.HTTP_403_FORBIDDEN)

    appointment = Appointment.objects.filter(_id=pk, mester=request.user.mester).first()
    if not appointment:
        return Response({"message": "Invalid Appointment."}, status=404)

    appointment.rejected = True
    appointment.save()
    return Response({"message": "Appointment successfully rejected."}, status=200)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def getListOfAppointments(request):
    user = request.user

    user_serializer = UserSerializer(user)
    is_customer = user_serializer.data.get('isCustomer', False)
    is_mester = user_serializer.data.get('isMester', False)

    if is_customer:
        appointments = Appointment.objects.filter(user = request.user)
        appointments = appointments.order_by('-date').all()

        serializer = AppointmentSerializer(appointments, many=True)
        return Response({"appointments": serializer.data}, status=200)
    elif is_mester:
        appointments = Appointment.objects.filter(mester = user.mester._id)
        appointments = appointments.order_by('-date').all()

        serializer = AppointmentSerializer(appointments, many=True)
        return Response({"appointments": serializer.data}, status=200)

@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def editAppointment(request, pk):

    data = request.data
    user = request.user
    date = data.get('date')

    user_serializer = UserSerializer(user)
    is_customer = user_serializer.data.get('isCustomer', False)

    if not is_customer:
        content = {'detail': 'Only customers can edit their appointments'}
        return Response(content, status=status.HTTP_403_FORBIDDEN)

    try:
        date = datetime.datetime.strptime(date, "%Y-%m-%d").date()
    except ValueError:
        return Response("Invalid date format. Use YYYY-MM-DD.", status=400)

    if date <= datetime.datetime.today().date():
        content = {'detail': 'Appointments must have dates starting tomorrow.'}
        return Response(content, status=400)

    appointment = Appointment.objects.filter(_id=pk, user=request.user).first()
    if not appointment:
        return Response({"message": "Invalid Appointment."}, status=404)

    appointment.date = date
    appointment.time_slot = data.get('time_slot')
    appointment.description = data.get('description')
    appointment.save()

    return Response({"detail":"Appointment successfully edited."}, status=200)

@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def deleteAppointment(request, pk):
    data = request.data
    user = data.get('user')

    appointment = Appointment.objects.filter(_id=pk, user=request.user).first()
    if not appointment:
        return Response({"message": "Invalid Appointment."}, status=404)

    appointment.delete()
    return Response({"detail":"Appointment successfully deleted."}, status=200)