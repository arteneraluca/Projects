from django.shortcuts import render
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.contrib.auth.models import User

from base.models import Customer, Mester
from base.serializers import CustomerSerializer, MesterSerializer, UserSerializer, UserSerializerWithToken

from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework_simplejwt.views import TokenObtainPairView

from django.contrib.auth.hashers import make_password
from rest_framework import status

class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
    def validate(self, attrs):
        data = super().validate(attrs)

        serializer = UserSerializerWithToken(self.user).data

        for k, v in serializer.items():
            data[k] = v

        return data

class MyTokenObtainPairView(TokenObtainPairView):
    serializer_class = MyTokenObtainPairSerializer

@api_view(['POST'])
def registerUser(request):
    data = request.data
    account_type = data.get('account_type', None)

    if account_type not in ['customer', 'mester']:
        return Response({'detail': 'Invalid account type'}, status=status.HTTP_400_BAD_REQUEST)
    
    try:
        user = User.objects.create(
            first_name = data['name'],
            username = data['email'],
            email = data['email'],
            password = make_password(data['password'])
        )

        if account_type == 'customer':
            customer = Customer.objects.create(user=user)
        else:
            mester = Mester.objects.create(
                user = user,
                categorie = data['categorie'],
                locatie = data['locatie'],
                descriere = data['descriere'],
            )
        serializer = UserSerializerWithToken(user, many=False)
        return Response(serializer.data)
    except:
        message = {'detail':'User with this email already exists'}
        return Response(message, status = status.HTTP_400_BAD_REQUEST)

@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def updateUserProfile(request):
    user = request.user
    data = request.data

    if hasattr(user, 'customer'):
        customer = user.customer
        customer_serializer = CustomerSerializer(customer, data=data)

        if customer_serializer.is_valid():
            if 'name' in data:
                user.first_name = data['name']
            if 'email' in data:
                user.email = data['email']
            if 'password' in data and data['password'] != '':
                user.password = make_password(data['password'])
            if 'profileImage' in data:
                customer.profileImage = data['profileImage']

            user.save()
            customer_serializer.save()

            serializer = UserSerializerWithToken(user, many=False)
            return Response(serializer.data)
        else:
            return Response(customer_serializer.errors, status=400)

    elif hasattr(user, 'mester'):
        mester = user.mester
        mester_serializer = MesterSerializer(mester, data=data)

        if mester_serializer.is_valid():
            if 'name' in data:
                user.first_name = data['name']
            if 'email' in data:
                user.email = data['email']
            if 'password' in data and data['password'] != '':
                user.password = make_password(data['password'])
            if 'profileImage' in data:
                mester.profileImage = data['profileImage']
            if 'categorie' in data:
                mester.categorie = data['categorie']
            if 'locatie' in data:
                mester.locatie = data['locatie']
            if 'descriere' in data:
                mester.descriere = data['descriere']

            user.save()
            mester_serializer.save()
            
            serializer = UserSerializerWithToken(user, many=False)
            return Response(serializer.data)
        else:
            return Response(mester_serializer.errors, status=400)

    else:
        return Response({'error': 'User is neither a customer nor a mester'}, status=400)
    
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def getUserProfile(request):
    user = request.user

    if hasattr(user, 'customer'):
        serializer = CustomerSerializer(user.customer, many=False)
    elif hasattr(user, 'mester'):
        serializer = MesterSerializer(user.mester, many=False)
    else:
        serializer = UserSerializer(user, many=False)

    return Response(serializer.data)

@api_view(['GET'])
def getUsers(request):
    users = User.objects.all()
    serializer = UserSerializer(users, many=True)
    return Response(serializer.data)

@api_view(['POST'])
def uploadProfileImage(request):
    data = request.data
    user_id = data['user_id']
    image = request.FILES.get('image')

    try:
        customer = Customer.objects.get(user=user_id)
        customer.profileImage = image
        customer.save()
        
        return Response('Customer profile image was uploaded')
    except Customer.DoesNotExist:
        pass

    try:
        mester = Mester.objects.get(user=user_id)
        mester.profileImage = image
        mester.save()
        return Response('Mester profile image was uploaded')
    except Mester.DoesNotExist:
        pass

    return Response('User not found', status=404)