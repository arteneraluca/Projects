from rest_framework import serializers
from django.contrib.auth.models import User
from rest_framework_simplejwt.tokens import RefreshToken
from .models import Customer, Mester, Review, Appointment

class UserSerializer(serializers.ModelSerializer):
    name = serializers.SerializerMethodField(read_only=True)
    isCustomer = serializers.SerializerMethodField(read_only=True)
    isMester = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = User
        fields = ['id','username','email', 'name', 'isCustomer', 'isMester']

    def get_isCustomer(self, obj):
        return hasattr(obj, 'customer')

    def get_isMester(self, obj):
        return hasattr(obj, 'mester')

    def get_name(self, obj):
        name = obj.first_name
        if name == '':
            name = obj.email
        return name

class UserSerializerWithToken(UserSerializer):
    token = serializers.SerializerMethodField(read_only=True)
    class Meta:
        model = User
        fields = ['id','username','email', 'name','isCustomer', 'isMester', 'token']

    def get_token(self, obj):
        token = RefreshToken.for_user(obj)
        return str(token.access_token)

class ReviewSerializer(serializers.ModelSerializer):
    class Meta:
        model = Review
        fields = '__all__'

class CustomerSerializer(serializers.ModelSerializer):
    isCustomer = serializers.SerializerMethodField()
    name = serializers.CharField(source='user.first_name', read_only=True)
    email = serializers.CharField(source='user.email', read_only=True)

    class Meta:
        model = Customer
        fields = ['user', '_id','name', 'email', 'profileImage', 'isCustomer']
        read_only_fields = ['user'] 

    def get_isCustomer(self, obj):
        return hasattr(obj.user, 'customer')

class MesterSerializer(serializers.ModelSerializer):

    isMester = serializers.SerializerMethodField()
    name = serializers.CharField(source='user.first_name', read_only=True)
    email = serializers.CharField(source='user.email', read_only=True)
    reviews = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = Mester
        fields = ['user', '_id','name', 'email','reviews', 'categorie', 'descriere','profileImage', 'locatie', 'rating', 'totalReviews', 'isMester']
        read_only_fields = ['user'] 

    def get_isMester(self, obj):
        return hasattr(obj.user, 'mester')

    def get_reviews(self, obj):
        reviews = obj.review_set.all()
        serializer = ReviewSerializer(reviews, many=True)
        return serializer.data

class AppointmentSerializer(serializers.ModelSerializer):
    name_customer = serializers.CharField(source='user.first_name', read_only=True)
    name_mester = serializers.CharField(source='mester.user.first_name', read_only=True)
    categorie_mester = serializers.CharField(source='mester.categorie', read_only=True)

    class Meta:
        model = Appointment
        fields = ['_id', 'name_customer', 'name_mester','categorie_mester', 'user', 'mester', 'date', 'time_slot', 'start_time', 'address', 'description', 'accepted', 'rejected']
        read_only_fields = ['name_customer', 'name_mester', 'categorie_mester'] 