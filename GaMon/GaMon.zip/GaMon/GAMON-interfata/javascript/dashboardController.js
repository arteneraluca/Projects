const privateButton = document.getElementById('private-button');
if (sessionStorage.getItem('account_type') === 'Citizen') {
    privateButton.style.display = 'none';
}

const displayedName = document.getElementById('displayed-name');
displayedName.innerHTML = sessionStorage.getItem('name');

